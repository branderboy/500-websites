---
name: seedance-2-replicate
description: Generate Seedance 2.0 videos via the Replicate API. Use this skill whenever the user wants to create AI video, generate a clip, animate an image, make a looping background, produce a video ad, or build video content using Seedance, ByteDance video, or Replicate video generation. Triggers on mentions of Seedance, Seedance 2.0, video generation, text-to-video, image-to-video, or requests like "make a video of", "generate a clip of", "animate this image", "create a looping background", or any video production workflow involving Replicate API keys. Also use when combining reference images or videos for style matching on generated clips.
---

# Seedance 2.0 via Replicate

This skill generates cinematic AI videos using ByteDance's Seedance 2.0 model through the Replicate API. Seedance 2.0 is a multimodal model that accepts text, images, video clips, and audio as input and produces MP4 video with synchronized native audio.

## When to use this skill

- User wants to generate a video from a text prompt
- User wants to animate a still image into video
- User has reference footage and wants to match its style, motion, or camera work
- User is building looping backgrounds for websites
- User is producing ads, product videos, or social content at scale
- User wants to extend or edit existing video clips

## Prerequisites

1. A Replicate API token. Sign up at replicate.com and grab the token from account settings.
2. Python 3.10+ installed.
3. A `.env` file in the working directory with:

```
REPLICATE_API_TOKEN=r8_your_token_here
```

4. The `replicate` and `python-dotenv` Python packages. If missing, install with:

```bash
pip install replicate python-dotenv requests
```

## Core workflow

The generation script lives at `scripts/generate.py`. It handles authentication, submits the job to Replicate, polls for completion, and downloads the finished MP4 to the output directory.

### Basic text-to-video

```bash
python scripts/generate.py \
  --prompt "A glass serum bottle on black marble, slow 180-degree orbital camera move, a single drop of amber liquid falls and splashes in slow motion, warm golden key light cutting diagonally, cinematic shallow depth of field" \
  --duration 8 \
  --aspect-ratio 9:16 \
  --output ./output/serum-ad.mp4
```

### Image-to-video (animate a still)

```bash
python scripts/generate.py \
  --prompt "Camera slowly pushes in on the subject, subtle wind moves their hair, natural breathing motion" \
  --first-frame ./inputs/hero-shot.jpg \
  --duration 5 \
  --aspect-ratio 16:9 \
  --output ./output/hero-animated.mp4
```

### Multimodal reference (style + motion matching)

```bash
python scripts/generate.py \
  --prompt "The character from [Image1] performs the movement from [Video1], in the lighting style of [Image2]" \
  --ref-images ./inputs/character.jpg ./inputs/lighting-ref.jpg \
  --ref-videos ./inputs/motion-ref.mp4 \
  --duration 8 \
  --aspect-ratio 9:16 \
  --output ./output/styled-clip.mp4
```

### Looping background for a website

```bash
python scripts/generate.py \
  --prompt "Abstract liquid gold swirling slowly against deep navy background, seamless continuous motion, no cuts, hypnotic, cinematic" \
  --duration 10 \
  --aspect-ratio 16:9 \
  --loop \
  --output ./output/bg-loop.mp4
```

The `--loop` flag tells the script to add a post-processing step that makes the first and last frames match for seamless looping.

## Prompt engineering for Seedance 2.0

Seedance 2.0 rewards specific, structured prompts. Use this formula:

**Subject + Action + Camera movement + Lighting + Style + Constraints**

### What works

- Specific camera language: "slow dolly-in", "orbital pan", "handheld tracking shot", "rack focus from foreground to background"
- Lens and film stock references: "shot on Arri Alexa", "anamorphic lens flares", "35mm film grain"
- Lighting direction: "warm golden hour side light", "cool blue key with warm rim", "harsh overhead practical"
- Physics cues: "slow motion splash", "fabric billows in the wind", "dust motes drift through light beams"
- For dialogue: put speech in double quotes. The model generates matching lip movement and voice: `The woman looks up and says: "We built this from nothing."`

### What breaks

- Vague style words alone ("cinematic", "beautiful", "epic") without specifics
- More than 2 subject or scene changes in under 8 seconds
- Small on-screen text (renders as garbage; add text in post instead)
- Contradictory motion ("static locked shot with camera pan")
- Prompts over 4,000 characters

### Reference syntax

When you pass reference images or videos, label them in the prompt as `[Image1]`, `[Image2]`, `[Video1]`, `[Audio1]`. The model connects the label to the uploaded file.

Example: `"The product from [Image1] rotating on a pedestal, in the cinematic lighting style of [Image2], matching the camera movement from [Video1]"`

## Aspect ratios and durations

| Use case | Aspect ratio | Duration |
|----------|-------------|----------|
| TikTok, Reels, Stories, paid social | 9:16 | 8s |
| YouTube, website hero | 16:9 | 8 to 10s |
| Square social feed | 1:1 | 6 to 8s |
| Cinematic widescreen | 21:9 | 10 to 15s |
| Looping background | 16:9 or 9:16 | 10 to 15s |

Supported durations: 4 to 15 seconds. Start with 5 to 8 seconds while iterating, then extend once you lock the style.

## Cost management

Standard Seedance 2.0 on Replicate costs approximately $0.15 per second of generated video. An 8-second clip costs around $1.20. Fast tier (`bytedance/seedance-2.0-fast`) is cheaper and faster but trades quality.

Before firing expensive runs:

1. Iterate prompts with the `--fast` flag (uses the fast tier) until the style is locked
2. Run a 5-second version before a 15-second version
3. Use `--dry-run` to preview the payload without submitting

## Batch generation

For running multiple variants (useful for ad creative testing):

```bash
python scripts/batch.py --config ./configs/ad-variants.yaml
```

See `scripts/batch.py` and `configs/ad-variants.example.yaml` for the structure.

## Extending existing videos

To continue a clip beyond its original length:

```bash
python scripts/generate.py \
  --prompt "Continue the scene: the camera continues pulling back to reveal the full landscape" \
  --extend-from ./output/part1.mp4 \
  --duration 8 \
  --output ./output/part2.mp4
```

## Troubleshooting

**Job times out or hangs**: Replicate jobs for Seedance 2.0 typically complete in 2 to 5 minutes. If the poll loop exceeds 10 minutes, kill it and check replicate.com/account for the job status. Long queues happen during peak hours.

**"Invalid model version" error**: Replicate sometimes pins specific model versions. Check the current version hash at replicate.com/bytedance/seedance-2.0 and update `SEEDANCE_MODEL` in `scripts/generate.py` if needed.

**Reference image rejected**: Images must be under 10MB, in JPEG, PNG, or WebP format. Videos must be under 15 seconds total across all uploaded clips and in MP4 or MOV format.

**Output video has no audio**: Seedance 2.0 generates native audio by default. If audio is missing, add explicit cues to the prompt: "ambient wind sound", "upbeat electronic music", or include a reference audio file.

**Character inconsistency across shots**: Upload a clean reference image of the character and reference it throughout the prompt: "the woman from [Image1]". The model holds consistency much better with a visual anchor than from text description alone.

## File structure this skill expects

```
project-root/
├── .env                           # REPLICATE_API_TOKEN lives here
├── scripts/
│   ├── generate.py                # main generation script
│   └── batch.py                   # batch runner for variant testing
├── inputs/                        # reference images, videos, audio
├── output/                        # generated MP4s land here
└── configs/
    └── ad-variants.example.yaml   # batch config template
```

If these don't exist yet in the project, create them before running.
