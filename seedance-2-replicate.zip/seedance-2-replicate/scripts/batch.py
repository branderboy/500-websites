#!/usr/bin/env python3
"""
Batch generator for Seedance 2.0. Runs multiple variants from a YAML config.

Usage:
    python scripts/batch.py --config ./configs/ad-variants.yaml
"""

import argparse
import subprocess
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("Missing dependency: pyyaml")
    print("Run: pip install pyyaml")
    sys.exit(1)


def run_variant(variant, defaults, script_path):
    """Run a single generate.py invocation from a variant dict."""
    merged = {**defaults, **variant}
    name = merged.get("name", "variant")
    output = merged.get("output") or f"./output/{name}.mp4"

    cmd = [sys.executable, str(script_path), "--output", output]

    if "prompt" in merged:
        cmd += ["--prompt", merged["prompt"]]
    if "duration" in merged:
        cmd += ["--duration", str(merged["duration"])]
    if "aspect_ratio" in merged:
        cmd += ["--aspect-ratio", merged["aspect_ratio"]]
    if "resolution" in merged:
        cmd += ["--resolution", merged["resolution"]]
    if "first_frame" in merged:
        cmd += ["--first-frame", merged["first_frame"]]
    if "last_frame" in merged:
        cmd += ["--last-frame", merged["last_frame"]]
    if "ref_images" in merged:
        cmd += ["--ref-images", *merged["ref_images"]]
    if "ref_videos" in merged:
        cmd += ["--ref-videos", *merged["ref_videos"]]
    if "ref_audio" in merged:
        cmd += ["--ref-audio", *merged["ref_audio"]]
    if "seed" in merged:
        cmd += ["--seed", str(merged["seed"])]
    if merged.get("fast"):
        cmd.append("--fast")
    if merged.get("loop"):
        cmd.append("--loop")
    if merged.get("dry_run"):
        cmd.append("--dry-run")

    print(f"\n{'='*60}")
    print(f"Variant: {name}")
    print(f"{'='*60}")
    result = subprocess.run(cmd)
    return name, result.returncode


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True, help="Path to YAML config file")
    p.add_argument("--continue-on-error", action="store_true",
                   help="Keep going if a variant fails")
    args = p.parse_args()

    config_path = Path(args.config)
    with open(config_path) as f:
        config = yaml.safe_load(f)

    defaults = config.get("defaults", {})
    variants = config.get("variants", [])

    if not variants:
        print("No variants defined in config.")
        sys.exit(1)

    script_path = Path(__file__).parent / "generate.py"

    results = []
    for variant in variants:
        name, code = run_variant(variant, defaults, script_path)
        results.append((name, code))
        if code != 0 and not args.continue_on_error:
            print(f"\nVariant '{name}' failed. Stopping. Use --continue-on-error to skip failures.")
            break

    print(f"\n{'='*60}")
    print("Batch complete")
    print(f"{'='*60}")
    for name, code in results:
        status = "OK" if code == 0 else f"FAIL (exit {code})"
        print(f"  {name}: {status}")


if __name__ == "__main__":
    main()
