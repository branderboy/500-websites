#!/usr/bin/env python3
"""
Seedance 2.0 video generation via Replicate API.

Handles text-to-video, image-to-video, and multimodal reference generation.
Loads API token from .env, submits job, polls for completion, downloads MP4.

Usage:
    python scripts/generate.py --prompt "..." --duration 8 --aspect-ratio 9:16 --output ./out.mp4
"""

import argparse
import os
import sys
import time
from pathlib import Path

try:
    import replicate
    from dotenv import load_dotenv
    import requests
except ImportError as e:
    print(f"Missing dependency: {e.name}")
    print("Run: pip install replicate python-dotenv requests")
    sys.exit(1)


SEEDANCE_MODEL = "bytedance/seedance-2.0"
SEEDANCE_FAST_MODEL = "bytedance/seedance-2.0-fast"


def load_env():
    """Load API token from .env in current dir or parent."""
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        env_path = parent / ".env"
        if env_path.exists():
            load_dotenv(env_path)
            break
    token = os.getenv("REPLICATE_API_TOKEN")
    if not token:
        print("ERROR: REPLICATE_API_TOKEN not found in .env or environment.")
        print("Add this to your .env file:")
        print("  REPLICATE_API_TOKEN=r8_your_token_here")
        sys.exit(1)
    os.environ["REPLICATE_API_TOKEN"] = token


def upload_if_local(path_or_url):
    """
    Replicate accepts either URLs or file handles. If we get a local path,
    open it as a file handle so the replicate client uploads it.
    Returns either the original URL string or an open file handle.
    """
    if path_or_url.startswith(("http://", "https://")):
        return path_or_url
    p = Path(path_or_url)
    if not p.exists():
        raise FileNotFoundError(f"Reference file not found: {path_or_url}")
    return open(p, "rb")


def build_input(args):
    """Build the input dict that Replicate expects."""
    payload = {
        "prompt": args.prompt,
        "duration": args.duration,
        "aspect_ratio": args.aspect_ratio,
    }

    if args.resolution:
        payload["resolution"] = args.resolution

    if args.first_frame:
        payload["image"] = upload_if_local(args.first_frame)

    if args.last_frame:
        payload["last_frame_image"] = upload_if_local(args.last_frame)

    if args.ref_images:
        payload["reference_images"] = [upload_if_local(p) for p in args.ref_images]

    if args.ref_videos:
        payload["reference_videos"] = [upload_if_local(p) for p in args.ref_videos]

    if args.ref_audio:
        payload["reference_audio"] = [upload_if_local(p) for p in args.ref_audio]

    if args.extend_from:
        payload["extend_from_video"] = upload_if_local(args.extend_from)

    if args.seed is not None:
        payload["seed"] = args.seed

    return payload


def generate(args):
    """Submit job, wait, download result."""
    model = SEEDANCE_FAST_MODEL if args.fast else SEEDANCE_MODEL
    payload = build_input(args)

    if args.dry_run:
        print("DRY RUN. Would submit to:", model)
        print("Payload (file handles shown as paths):")
        preview = {}
        for k, v in payload.items():
            if isinstance(v, list):
                preview[k] = [getattr(x, "name", str(x)) for x in v]
            else:
                preview[k] = getattr(v, "name", str(v)) if hasattr(v, "read") else v
        for k, v in preview.items():
            print(f"  {k}: {v}")
        return

    print(f"Submitting to {model}...")
    print(f"Duration: {args.duration}s, Aspect: {args.aspect_ratio}")
    start = time.time()

    output = replicate.run(model, input=payload)

    # Replicate returns either a URL string or an object with .url()
    video_url = output if isinstance(output, str) else getattr(output, "url", lambda: str(output))()

    elapsed = time.time() - start
    print(f"Generation complete in {elapsed:.1f}s")
    print(f"Remote URL: {video_url}")

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    print(f"Downloading to {out_path}...")
    r = requests.get(video_url, stream=True, timeout=300)
    r.raise_for_status()
    with open(out_path, "wb") as f:
        for chunk in r.iter_content(chunk_size=1 << 20):
            f.write(chunk)

    size_mb = out_path.stat().st_size / (1024 * 1024)
    print(f"Saved {size_mb:.1f}MB to {out_path}")

    if args.loop:
        print("Loop flag set. Running ffmpeg pass to crossfade first and last seconds...")
        make_loop(out_path)


def make_loop(path):
    """Crossfade the end into the beginning for seamless looping. Requires ffmpeg."""
    import subprocess
    tmp = path.with_suffix(".loop.mp4")
    cmd = [
        "ffmpeg", "-y", "-i", str(path),
        "-filter_complex",
        "[0:v]split[a][b];[a]trim=start=0:end=1,setpts=PTS-STARTPTS[head];"
        "[b]trim=start=1,setpts=PTS-STARTPTS[body];"
        "[body][head]xfade=transition=fade:duration=1:offset=0[v]",
        "-map", "[v]", "-c:v", "libx264", "-crf", "18", "-preset", "medium",
        str(tmp)
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        tmp.replace(path)
        print(f"Looped version saved over {path}")
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"Loop post-process failed (ffmpeg may not be installed): {e}")
        print("Original non-looped file is still saved.")


def parse_args():
    p = argparse.ArgumentParser(
        description="Generate video with Seedance 2.0 via Replicate.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--prompt", required=True, help="Text prompt describing the video")
    p.add_argument("--output", required=True, help="Path to save the output MP4")
    p.add_argument("--duration", type=int, default=8, choices=range(4, 16),
                   metavar="[4-15]", help="Video duration in seconds (4 to 15)")
    p.add_argument("--aspect-ratio", default="9:16",
                   choices=["9:16", "16:9", "1:1", "4:3", "3:4", "21:9"],
                   help="Aspect ratio of output video")
    p.add_argument("--resolution", choices=["480p", "720p"], default="720p")
    p.add_argument("--first-frame", help="Path or URL to first frame image")
    p.add_argument("--last-frame", help="Path or URL to last frame image")
    p.add_argument("--ref-images", nargs="+", help="Reference images, max 9")
    p.add_argument("--ref-videos", nargs="+", help="Reference videos, max 3, 15s total")
    p.add_argument("--ref-audio", nargs="+", help="Reference audio files, max 3")
    p.add_argument("--extend-from", help="Path to video to extend")
    p.add_argument("--seed", type=int, help="Random seed for reproducibility")
    p.add_argument("--fast", action="store_true",
                   help="Use seedance-2.0-fast (cheaper, quicker, slightly lower quality)")
    p.add_argument("--loop", action="store_true",
                   help="Post-process to make video loop seamlessly (requires ffmpeg)")
    p.add_argument("--dry-run", action="store_true",
                   help="Print the payload without submitting")
    return p.parse_args()


def main():
    args = parse_args()
    load_env()
    generate(args)


if __name__ == "__main__":
    main()
