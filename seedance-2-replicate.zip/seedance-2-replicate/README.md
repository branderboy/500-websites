# Seedance 2.0 via Replicate (Claude Code Skill)

A Claude Code skill that generates Seedance 2.0 videos through the Replicate API. Drop it into your skills directory, give Claude Code a prompt, and it writes, submits, and downloads the finished MP4 for you.

## What this gives you

- Text-to-video generation (prompt only)
- Image-to-video generation (animate a still)
- Multimodal reference generation (match style, motion, or character from existing media)
- Batch generation for testing ad creative variants
- Looping background generation with seamless crossfade
- Video extension (continue an existing clip)

## Install

**1. Install the skill**

Copy the whole `seedance-2-replicate` folder into your Claude Code skills directory:

```bash
# macOS / Linux
cp -r seedance-2-replicate ~/.claude/skills/

# Windows (PowerShell)
Copy-Item -Recurse seedance-2-replicate $HOME\.claude\skills\
```

**2. Install Python dependencies**

```bash
pip install replicate python-dotenv requests pyyaml
```

`ffmpeg` is only required if you want to use the `--loop` seamless looping feature. Install from ffmpeg.org or via your package manager.

**3. Set up your API token**

Get a Replicate API token from https://replicate.com/account/api-tokens

Copy `.env.example` to `.env` in your project root and paste your token:

```
REPLICATE_API_TOKEN=r8_your_actual_token_here
```

**4. Restart Claude Code**

Claude Code loads skills on startup. Restart the session and the skill will be available.

## Usage with Claude Code

Once installed, just talk to Claude Code naturally:

```
> Make a looping background for my website hero. Amber liquid swirling
  slowly against deep navy, 10 seconds, 16:9.

> Take this product photo and turn it into an 8-second Meta ad. Slow
  orbital camera, warm lighting, vertical format.

> Generate three variants of that ad with different hooks for A/B testing.
```

Claude Code will call the scripts, handle the API, and save the MP4 to your output folder.

## Manual usage (without Claude Code)

You can run the scripts directly:

```bash
# Text-to-video
python scripts/generate.py \
  --prompt "A cinematic shot of a contractor framing a wall at golden hour" \
  --duration 8 \
  --aspect-ratio 9:16 \
  --output ./output/test.mp4

# Image-to-video
python scripts/generate.py \
  --prompt "Slow push in, subtle motion" \
  --first-frame ./inputs/hero.jpg \
  --duration 5 \
  --output ./output/animated.mp4

# Batch variants
python scripts/batch.py --config ./configs/ad-variants.example.yaml

# Preview without spending credits
python scripts/generate.py --prompt "..." --output ./out.mp4 --dry-run
```

## Cost

Approximately $0.15 per second of generated video on the standard tier. An 8-second clip is about $1.20. Use `--fast` while iterating to cut that significantly, then switch to standard for final renders.

## File layout

```
seedance-2-replicate/
├── SKILL.md                   # Skill definition Claude Code reads
├── README.md                  # This file
├── .env.example               # Template for API token
├── scripts/
│   ├── generate.py            # Single-video generator
│   └── batch.py               # Batch runner for variants
└── configs/
    └── ad-variants.example.yaml
```

## License

Use it. Modify it. No warranty.
